﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class MarksDetail
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        cn.Open()

        cmd = New OleDbCommand("select * from AddMarks where Sr_no=" + TxtSearch.Text, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        GridView1.DataSource = dt
        GridView1.DataBind()
        cn.Close()

    End Sub
    Public Sub data()
        Dim str As String = ConfigurationManager.ConnectionStrings("database9").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
        da = New OleDbDataAdapter("select * from AddMarks order by Sr_no", cn)
        ds = New DataSet()
        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

        cn.Close()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        data()
    End Sub

    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
    End Sub
End Class
