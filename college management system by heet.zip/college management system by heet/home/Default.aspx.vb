﻿Imports System.Data.OleDb
Public Class _Default
    Inherits System.Web.UI.Page
    Dim cn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\HEETDAYANI\Desktop\Minor project sem-5\CMS BY heet\CMS\App_Data\cms.mdb")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn.Open()
        Try
            Dim userid As String = Session("USERid")
            Dim cmd As New OleDbCommand("select * from LOGIN where userid='" & userid & "' ", cn)
            Dim dr As OleDbDataReader = cmd.ExecuteReader
            dr.Read()
            username.Text = dr("Fullname")
            Session("department") = dr("Department")
        Catch ex As Exception
        End Try
        cn.Close()
    End Sub

    Private Sub logout_Click(sender As Object, e As EventArgs) Handles logout.Click

    End Sub
End Class