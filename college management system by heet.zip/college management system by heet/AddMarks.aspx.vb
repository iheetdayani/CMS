﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class AddMarks
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim str As String = ConfigurationManager.ConnectionStrings("database9").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
        cn.Close()
    End Sub
    Public Sub data()
        Dim str As String = ConfigurationManager.ConnectionStrings("database9").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()

        cn.Close()
    End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
      
        cn.Open()
        cmd = New OleDbCommand("insert into AddMarks(Class,Subject,Student_Roll_No,Total_Marks,Out_Of_Marks) values('" + ddlClass.SelectedValue + "','" + txtSubject.SelectedValue + "','" + txtRoll_No.SelectedValue + "','" + txtTotalMarks.Text + "','" + txtOutMarks.Text + "')", cn)
        cmd.ExecuteNonQuery()

        cn.Close()
        data()
    End Sub

   

    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging

        GridView1.PageIndex = e.NewPageIndex

    End Sub
End Class
