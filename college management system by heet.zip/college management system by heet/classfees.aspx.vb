﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class classfees
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        cn.Open()
        If (TextBox1.Text = "" Or txtfeesamount.Text = "") Then
            MsgBox("Enter Field", MsgBoxStyle.Exclamation)
        Else
            cmd = New OleDbCommand("insert into addfees(Fees_Id,Class,Fees) values(" + TextBox1.Text + ",'" + DropDownList1.SelectedValue + "','" + txtfeesamount.Text + "')", cn)
            cmd.ExecuteNonQuery()
        End If
       
        cn.Close()
        data()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        data()
    End Sub
    Public Sub data()
        Dim str As String = ConfigurationManager.ConnectionStrings("database9").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
        da = New OleDbDataAdapter("select * from addfees order by Fees_Id", cn)
        ds = New DataSet()
        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

        cn.Close()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        DropDownList1.ClearSelection()
        txtfeesamount.Text = ""
        TextBox1.Text = ""
    End Sub

    Protected Sub btnfind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfind.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Fees_Id", MsgBoxStyle.Exclamation)
        Else
            Dim dr As OleDbDataReader
            cmd = New OleDbCommand("select * from addfees where Fees_Id=" + TextBox1.Text, cn)
            dr = cmd.ExecuteReader()
            dr.Read()
            DropDownList1.SelectedValue = dr("Class").ToString()
            txtfeesamount.Text = dr("Fees").ToString()
        End If
        
        cn.Close()
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Fees_Id", MsgBoxStyle.Exclamation)
        Else

            cmd = New OleDbCommand("delete from addfees where Fees_Id= " + TextBox1.Text, cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        TextBox1.Text = ""
        txtfeesamount.Text = ""
        DropDownList1.ClearSelection()
        data()
    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Fees_Id", MsgBoxStyle.Exclamation)
        Else

            Dim update As String
            update = "UPDATE addfees SET [Fees]=" + txtfeesamount.Text + " WHERE[Fees_Id]=" + TextBox1.Text + ""
            cmd = New OleDbCommand(update, cn)
            cmd.ExecuteNonQuery()
        End If

        cn.Close()
        data()
    End Sub

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        cn.Open()
        If TextBox1.Text = "" Then
            MsgBox("Enter Fees_Id", MsgBoxStyle.Exclamation)
        Else

            cmd = New OleDbCommand("select * from addfees where Fees_Id=" + TextBox1.Text, cn)
            Dim da As New OleDbDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If

        cn.Close()
    End Sub

    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
    End Sub
End Class
