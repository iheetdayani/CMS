﻿
Partial Class aboutus1
    Inherits System.Web.UI.Page

End Class
