﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class TeachAtt
    Inherits System.Web.UI.Page
    Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\College managemnet system prince\College_managements-main\college\Database9.mdb"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindGridView()
        End If
    End Sub
    Private Sub BindGridView()
        Dim query As String = "SELECT Teacher_Id, Teacher_Name FROM addTeacher order by Teacher_Id"
        Dim connection As New OleDbConnection(connectionString)
        Dim adapter As New OleDbDataAdapter(query, connection)
        Dim dataset As New DataSet()

        adapter.Fill(dataset)

        If dataset.Tables.Count > 0 Then
            GridView1.DataSource = dataset.Tables(0)
            GridView1.DataBind()
        End If

        connection.Close()
    End Sub

    Protected Sub MarkAttendance_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim connection As New OleDbConnection(connectionString)
        connection.Open()

        Dim currentDate As DateTime = DateTime.Now.Date

        For Each row As GridViewRow In GridView1.Rows
            Dim studentID As String = row.Cells(0).Text
            Dim rblAttendance As RadioButtonList = DirectCast(row.FindControl("rblAttendance"), RadioButtonList)
            Dim attendanceValue As String = rblAttendance.SelectedValue

            ' Insert attendance record into the database
            Dim insertQuery As String = "INSERT INTO Attendance (Teacher_Id, AttendanceStatus, AttendanceDate) VALUES (@Teacher_Id, @AttendanceStatus, @AttendanceDate)"
            Dim insertCommand As New OleDbCommand(insertQuery, connection)
            insertCommand.Parameters.AddWithValue("@Teacher_Id", studentID)
            insertCommand.Parameters.AddWithValue("@AttendanceStatus", attendanceValue)
            insertCommand.Parameters.AddWithValue("@AttendanceDate", currentDate)
            insertCommand.ExecuteNonQuery()
        Next

        connection.Close()

        ' Refresh the GridView after marking attendance
        BindGridView()

        Dim script As String = "alert('Attendance saved in the database.');"
        ClientScript.RegisterStartupScript(Me.GetType(), "AlertScript", script, True)
    End Sub
End Class
