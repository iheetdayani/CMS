﻿Imports System.Data.OleDb
Imports System.Data
Imports System.Configuration
Partial Class AddClass
    Inherits System.Web.UI.Page
    Dim cn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        cn.Open()
        If txtClass.Text = "" Then
            MsgBox("Enter Class Name", MsgBoxStyle.Exclamation)
        Else
            cmd = New OleDbCommand("insert into addclass(ClassId,ClassName) values(" + txtClassId.Text + ",'" + txtClass.Text + "')", cn)
            cmd.ExecuteNonQuery()
            cn.Close()

        End If
        data()


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        data()
    End Sub
    Public Sub data()
        Dim str As String = ConfigurationManager.ConnectionStrings("database9").ConnectionString
        cn = New OleDbConnection(str)
        cn.Open()
        da = New OleDbDataAdapter("select * from addclass order by ClassId", cn)
        ds = New DataSet()
        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

        cn.Close()

    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        cn.Open()
        
            Dim update As String
            update = "UPDATE addclass SET [ClassName]='" + txtClass.Text + "' WHERE[ClassId]=" + txtClassId.Text + ""
            cmd = New OleDbCommand(update, cn)
            cmd.ExecuteNonQuery()
        cn.Close()
        data()
    End Sub

    Protected Sub btnfind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfind.Click
        cn.Open()

        Dim dr As OleDbDataReader
        cmd = New OleDbCommand("select * from addclass where ClassId=" + txtClassId.Text, cn)
            dr = cmd.ExecuteReader()
            dr.Read()
        txtClass.Text = dr("ClassName").ToString()
        cn.Close()
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        cn.Open()
        cmd = New OleDbCommand("delete from addclass where ClassId= " + txtClassId.Text, cn)
        cmd.ExecuteNonQuery()
        cn.Close()
        txtClassId.Text = ""
        txtClass.Text = ""
        data()
    End Sub

    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        cn.Open()
        cmd = New OleDbCommand("select * from addclass where ClassId=" + txtClassId.Text, cn)
        Dim da As New OleDbDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        GridView1.DataSource = dt
        GridView1.DataBind()
        cn.Close()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        'clr
        txtClass.Text = ""
        txtClassId.Text = ""
        data()
    End Sub

    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
    End Sub
End Class
